package view;

public class AdminMenuView 
{
    
    public static void DisplayAdminMenuView() 
    {
        System.out.println("Select any options in below for Admin :");
 
        System.out.println("1. Add New Rooms into hotel which are available");
        
        System.out.println("2. Select for Browsing Rooms");
     
        System.out.println("3. Delete Rooms from availability");
        
        System.out.println("4. Update Rooms in availability");
        System.out.println("5. View Admins");
        
        System.out.println("6. Register New Admin");
        
        System.out.println("7. Delete Admin");
        
        System.out.println("8. View Guests");
        
        System.out.println("9. Register New Guest");
        
        System.out.println("10. Delete Guest");
       
        System.out.println("11. Go back to the Menu");     
       
    }
}
