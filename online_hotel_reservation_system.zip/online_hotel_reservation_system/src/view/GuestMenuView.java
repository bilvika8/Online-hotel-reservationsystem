package view;



public class GuestMenuView 


{

    public static void DisplayGuestMenu() 
    
    {
        System.out.println("Select any option from below for guest menu:");
        
        System.out.println("1. Select for Browsing Rooms");
        
        System.out.println("2. Select for Reserving a Room");
        
        System.out.println("3. Modify the Reservation in Guest");
        
        System.out.println("4. Select for Cancelling Reservation in Guest");
        
        System.out.println("5. Go back to the Menu");
        
    }
    
}
