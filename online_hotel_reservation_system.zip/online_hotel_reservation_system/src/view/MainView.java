package view;


public class MainView 
{
    public static void DisplayHomeView() 
    {
       
        System.out.println("This is ONLINE HOTEL RESERVATION SYSTEM");
        System.out.println("Please select any option from below:");
        System.out.println("1. Admin/Employee Login");        
        System.out.println("3. Admin/Employee Registration");
        System.out.println("2. Login to Guest");
        System.out.println("4. Guest Registration");
    }
}
