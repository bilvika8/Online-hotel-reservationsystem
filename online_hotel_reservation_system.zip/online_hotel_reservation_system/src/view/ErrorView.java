package view;

public class ErrorView 
{
   
    public void print()
    {
   
    	System.out.println("Falied to login into hotel reservation system");
    	
    }
    
}
