package model;

public interface Cmnd 
{
    void execute();
}